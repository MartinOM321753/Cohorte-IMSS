package imss.gob.mx.cohorte.modules.estudios.parametros;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface ParametroEstudioRepository extends JpaRepository<ParametroEstudio, Long> {
    Optional<ParametroEstudio> findByNombre(String nombre);

    List<ParametroEstudio> findAllByTipoEstudio_Nombre(String tipoEstudioNombre);
}
